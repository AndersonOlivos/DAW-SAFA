package modelos;

public enum TipoHabilidad {
    DANIO, CURACION, BUFO_VIDA,
    BUFO_DEFENSA, BUFO_PODER
}
