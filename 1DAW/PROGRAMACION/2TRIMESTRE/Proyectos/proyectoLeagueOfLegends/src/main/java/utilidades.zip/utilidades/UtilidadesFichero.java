package utilidades;

public class UtilidadesFichero {
}
