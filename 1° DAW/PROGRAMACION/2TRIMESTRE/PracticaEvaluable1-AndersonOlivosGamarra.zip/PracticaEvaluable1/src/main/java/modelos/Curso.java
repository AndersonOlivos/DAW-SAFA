package modelos;

public enum Curso {
    PRIMARIA, SECUNDARIA, BACH, CICLOS
}
