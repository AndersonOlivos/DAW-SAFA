package utilidades;

public class UtilidadesLineaFactura {
}
