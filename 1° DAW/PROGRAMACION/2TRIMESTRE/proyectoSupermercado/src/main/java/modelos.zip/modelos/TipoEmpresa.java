package modelos;

public enum TipoEmpresa {
    PYME,
    STARTUP,
    NACIONAL,
    MULTINACIONAL
}
