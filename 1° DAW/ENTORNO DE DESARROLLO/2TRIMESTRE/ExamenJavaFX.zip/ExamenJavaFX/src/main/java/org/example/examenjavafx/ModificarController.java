package org.example.examenjavafx;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class ModificarController {
    @FXML
    private Label welcomeText;

    @FXML
    protected void onHelloButtonClick() {
        welcomeText.setText("Welcome to JavaFX Application!");
    }
}