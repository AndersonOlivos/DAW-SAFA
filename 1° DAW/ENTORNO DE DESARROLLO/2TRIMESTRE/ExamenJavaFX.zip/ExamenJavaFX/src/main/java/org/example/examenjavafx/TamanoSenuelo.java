package org.example.examenjavafx;

public enum TamanoSenuelo {
    PEQUEÑO, MEDIANO, GRANDE
}
