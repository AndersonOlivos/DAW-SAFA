public interface PersonajeMarvel {
    public String getNombre();
    public void setNombre(String nombre);
    public String getAlias();
    public Boolean getEsHeroe();
    public void setEsHeroe(Boolean esHeroe);
    public String getPoderPrincipal();
    public void setPoderPrincipal(String poderPrincipal);
    public String getAfiliacion();
    public void setAfiliacion(String afiliacion);
    public Double getPoder();
    public void setPoder(Double poder);
}
