public interface Enfrentamiento {
    public Equipo getEquipo1();
    public Equipo getEquipo2();
    public void simularEnfrentamiento(Equipo equipo1, Equipo equipo2);
}
