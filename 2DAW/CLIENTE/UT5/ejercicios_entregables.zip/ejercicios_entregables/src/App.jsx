import './App.css'
import Ejercicio1 from "./components/ejercicio1.jsx";
import Ejercicio2 from "./components/ejercicio2.jsx";
import Ejercicio3 from "./components/ejercicio3.jsx";

function App() {

  return (
    <>
        <Ejercicio1></Ejercicio1>
        <Ejercicio2></Ejercicio2>
        <Ejercicio3></Ejercicio3>
    </>
  )
}

export default App
